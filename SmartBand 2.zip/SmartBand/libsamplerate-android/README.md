libsamplerate-android
=====================

Port to android, base on libsamplerate-0.1.3

Build:

```shell
cd ./android/
ndk-build
```

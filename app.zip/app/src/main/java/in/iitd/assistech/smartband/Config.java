package in.iitd.assistech.smartband;

/**
 * Created by himanshu on 9/3/18.
 */

public class Config {
    // File upload url (replace the ip with your server address)
    public static final String FILE_UPLOAD_URL = "http://10.17.5.48:8000/sample/fileUpload.php";

    // Directory name to store captured images and videos10.17.5.48:8000
    public static final String IMAGE_DIRECTORY_NAME = "sample";
}

package in.iitd.assistech.smartband;

public interface OnTabEvent {
    void onButtonClick(String text);
}
